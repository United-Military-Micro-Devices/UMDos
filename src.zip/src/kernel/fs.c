/* fs.c - UMDFS：超级块 + 目录项表（支持子目录）+ 块位图 + 数据区 */
#include "fs.h"
#include "io.h"
#include "ata.h"

#define ROOT_DIR 0xFFFFFFFFu

typedef struct {
    u8  magic[8];
    u32 block_size;
    u32 block_count;
    u32 file_count;
    u32 data_start;
    u32 dirent_block;
    u32 dirent_count;
    u32 bitmap_block;
    u32 magic2;
} super_t;

static u8 *fs_base;
static u32 fs_bytes;
static super_t sb;
static int mounted;
static u32 cwd = ROOT_DIR;

static u8 *block_ptr(u32 blk) { return fs_base + (u64)blk * sb.block_size; }
static super_t *SB(void) { return (super_t *)fs_base; }
static u8 *bitmap(void) { return block_ptr(sb.bitmap_block); }

static int bit_test(u32 b) { return (bitmap()[b >> 3] >> (b & 7)) & 1; }

static void bit_set(u32 b, int value)
{
    if (value)
        bitmap()[b >> 3] |= (u8)(1u << (b & 7));
    else
        bitmap()[b >> 3] &= (u8)~(1u << (b & 7));
}

static char upper(char c) { return (c >= 'a' && c <= 'z') ? (char)(c - 32) : c; }

static int name_eq(const char *a, const char *b)
{
    while (*a && *b) {
        if (upper(*a) != upper(*b)) return 0;
        a++; b++;
    }
    return upper(*a) == upper(*b);
}

static fs_entry_t *dirent(int i)
{
    return (fs_entry_t *)(block_ptr(sb.dirent_block) + (u64)i * 64);
}

/* ---------------- 挂载 ---------------- */
int fs_mount(void *image, u32 bytes)
{
    mounted = 0;
    fs_base = (u8 *)image;
    fs_bytes = bytes;
    cwd = ROOT_DIR;
    if (!fs_base || bytes < 4096)
        return -1;

    super_t *s = SB();
    for (int i = 0; i < 8; i++)
        if (s->magic[i] != "UMDFS1\0\0"[i])
            return -2;
    if (s->magic2 != 0x46533031u || s->block_size != 512 || s->block_count == 0)
        return -3;
    if ((u64)s->block_count * s->block_size > bytes)
        return -4;

    sb = *s;
    if (sb.dirent_count > 64) sb.dirent_count = 64;
    mounted = 1;
    return 0;
}

/* ---------------- 目录 ---------------- */
u32 fs_dir(void) { return cwd; }

int fs_set_dir(u32 dir)
{
    if (!mounted) return -1;
    if (dir == ROOT_DIR) { cwd = ROOT_DIR; return 0; }
    if (dir >= sb.dirent_count) return -1;
    fs_entry_t *e = dirent((int)dir);
    if (!e->used || e->type != 1) return -1;
    cwd = dir;
    return 0;
}

static int find_in(u32 dir, const char *name)
{
    for (int i = 0; i < (int)sb.dirent_count; i++) {
        fs_entry_t *e = dirent(i);
        if (e->used && e->parent == dir && name_eq(e->name, name))
            return i;
    }
    return -1;
}

int fs_chdir(const char *path)
{
    if (!path) return -1;
    u32 dir = (path[0] == '/') ? ROOT_DIR : cwd;
    while (*path == '/') path++;
    while (*path) {
        char comp[32];
        int n = 0;
        while (path[n] && path[n] != '/' && n < 31) { comp[n] = path[n]; n++; }
        comp[n] = 0;
        path += n;
        while (*path == '/') path++;
        if (!n) continue;
        if (comp[0] == '.' && comp[1] == '.' && comp[2] == 0) {
            if (dir != ROOT_DIR) dir = dirent((int)dir)->parent;
            continue;
        }
        if (comp[0] == '.' && comp[1] == 0) continue;
        int idx = find_in(dir, comp);
        if (idx < 0) return -2;
        if (dirent(idx)->type != 1) return -3;
        dir = (u32)idx;
    }
    cwd = dir;
    return 0;
}

int fs_up(void)
{
    if (cwd == ROOT_DIR) return -1;
    cwd = dirent((int)cwd)->parent;
    return 0;
}

/* 当前路径，形如 "C:\DOCS" */
void fs_path(char *out, u32 cap)
{
    char tmp[8][32];
    int depth = 0;
    u32 d = cwd;
    while (d != ROOT_DIR && depth < 8) {
        const fs_entry_t *e = dirent((int)d);
        for (int i = 0; i < 31 && e->name[i]; i++) tmp[depth][i] = e->name[i];
        tmp[depth][31] = 0;
        int n = 0;
        while (tmp[depth][n]) n++;
        tmp[depth][n] = 0;
        depth++;
        d = e->parent;
    }
    u32 p = 0;
    const char *pre = "C:\\";
    while (*pre && p + 1 < cap) out[p++] = *pre++;
    for (int i = depth - 1; i >= 0; i--) {
        for (int k = 0; tmp[i][k] && p + 1 < cap; k++) out[p++] = tmp[i][k];
        if (i > 0 && p + 1 < cap) out[p++] = '\\';
    }
    out[p] = 0;
}

/* ---------------- 读取 ---------------- */
int fs_count(void)
{
    if (!mounted) return 0;
    int n = 0;
    for (int i = 0; i < (int)sb.dirent_count; i++) {
        fs_entry_t *e = dirent(i);
        if (e->used && e->parent == cwd) n++;
    }
    return n;
}

const fs_entry_t *fs_get(int index)
{
    if (!mounted || index < 0) return NULL;
    int n = 0;
    for (int i = 0; i < (int)sb.dirent_count; i++) {
        fs_entry_t *e = dirent(i);
        if (e->used && e->parent == cwd) {
            if (n == index) return e;
            n++;
        }
    }
    return NULL;
}

int fs_find(const char *name)
{
    if (!mounted) return -1;
    return find_in(cwd, name);
}

int fs_entry_index(const fs_entry_t *e)
{
    if (!mounted || !e) return -1;
    const u8 *base = block_ptr(sb.dirent_block);
    const u8 *p = (const u8 *)e;
    if (p < base || p >= base + (u64)sb.dirent_count * 64)
        return -1;
    return (int)((p - base) / 64);
}

int fs_is_dir(const fs_entry_t *e) { return e && e->type == 1; }

const u8 *fs_data(const fs_entry_t *e)
{
    if (!mounted || !e || e->type == 1)
        return NULL;
    if (e->size == 0)
        return fs_base;
    if (e->first_block >= sb.block_count)
        return NULL;
    const u8 *p = block_ptr(e->first_block);
    if (p + e->size > fs_base + fs_bytes)
        return NULL;
    return p;
}

u32 fs_block_size(void) { return mounted ? sb.block_size : 0; }
u32 fs_block_count(void) { return mounted ? sb.block_count : 0; }
const u8 *fs_raw(void) { return fs_base; }

u32 fs_free_blocks(void)
{
    if (!mounted) return 0;
    u32 n = 0;
    for (u32 b = 0; b < sb.block_count; b++)
        if (!bit_test(b)) n++;
    return n;
}

const char *fs_label(void) { return mounted ? "UMDFS1" : "none"; }

/* ---------------- 写入 ---------------- */
static u32 blocks_for(u32 size)
{
    u32 n = (size + sb.block_size - 1) / sb.block_size;
    return n ? n : 1;
}

static int alloc_run(u32 n, u32 *out)
{
    u32 run = 0, start = 0;
    for (u32 b = sb.data_start; b < sb.block_count; b++) {
        if (!bit_test(b)) {
            if (!run) start = b;
            run++;
            if (run == n) {
                for (u32 i = 0; i < n; i++) bit_set(start + i, 1);
                *out = start;
                return 0;
            }
        } else {
            run = 0;
        }
    }
    return -1;
}

static void free_run(u32 start, u32 n)
{
    for (u32 i = 0; i < n; i++) bit_set(start + i, 0);
}

static u32 used_blocks(const fs_entry_t *e) { return blocks_for(e->size); }

static void set_name(fs_entry_t *e, const char *name)
{
    for (int k = 0; k < 32; k++) e->name[k] = 0;
    int k = 0;
    while (name[k] && k < 31) { e->name[k] = name[k]; k++; }
    e->name[k] = 0;
}

int fs_write(const char *name, const void *data, u32 size)
{
    if (!mounted || !name || !*name || size > 64 * 1024)
        return -1;

    int idx = find_in(cwd, name);
    u32 need = blocks_for(size), start = 0;

    if (idx >= 0) {
        fs_entry_t *e = dirent(idx);
        if (e->type == 1) return -4;             /* 不能写目录 */
        u32 had = used_blocks(e);
        u32 old_start = e->first_block;
        if (need <= had) {
            start = old_start;
            if (need < had) free_run(old_start + need, had - need);
        } else {
            u32 ns = 0;
            if (alloc_run(need, &ns) != 0) return -2;
            free_run(old_start, had);
            start = ns;
        }
        e->size = size;
        e->first_block = start;
        e->used = 1;
        e->type = 0;
    } else {
        int slot = -1;
        for (int i = 0; i < (int)sb.dirent_count; i++)
            if (!dirent(i)->used) { slot = i; break; }
        if (slot < 0) return -3;
        if (alloc_run(need, &start) != 0) return -2;
        fs_entry_t *e = dirent(slot);
        set_name(e, name);
        e->size = size;
        e->first_block = start;
        e->used = 1;
        e->type = 0;
        e->parent = cwd;
        SB()->file_count = SB()->file_count + 1;
    }

    if (size && data) {
        u8 *dst = block_ptr(start);
        const u8 *src = (const u8 *)data;
        for (u32 i = 0; i < size; i++) dst[i] = src[i];
    }
    return 0;
}

int fs_mkdir(const char *name)
{
    if (!mounted || !name || !*name) return -1;
    if (find_in(cwd, name) >= 0) return -3;
    int slot = -1;
    for (int i = 0; i < (int)sb.dirent_count; i++)
        if (!dirent(i)->used) { slot = i; break; }
    if (slot < 0) return -3;
    fs_entry_t *e = dirent(slot);
    set_name(e, name);
    e->size = 0;
    e->first_block = 0;
    e->used = 1;
    e->type = 1;
    e->parent = cwd;
    SB()->file_count = SB()->file_count + 1;
    return 0;
}

int fs_dir_empty(u32 dir)
{
    for (int i = 0; i < (int)sb.dirent_count; i++) {
        fs_entry_t *e = dirent(i);
        if (e->used && e->parent == dir) return 0;
    }
    return 1;
}

int fs_unlink(const char *name)
{
    int idx = find_in(cwd, name);
    if (idx < 0) return -1;
    fs_entry_t *e = dirent(idx);
    if (e->type == 1) {
        if (!fs_dir_empty((u32)idx)) return -4;
    } else {
        free_run(e->first_block, used_blocks(e));
    }
    e->used = 0;
    e->size = 0;
    e->first_block = 0;
    if (SB()->file_count) SB()->file_count = SB()->file_count - 1;
    return 0;
}

int fs_rename(const char *oldname, const char *newname)
{
    int idx = find_in(cwd, oldname);
    if (idx < 0 || !newname || !*newname || find_in(cwd, newname) >= 0)
        return -1;
    set_name(dirent(idx), newname);
    return 0;
}

/* ---------------- 落盘 ---------------- */
static int backing;
static u32 backing_lba;

void fs_set_backing(u32 lba) { backing_lba = lba; backing = 1; }
int fs_backed(void) { return backing && ata_present(); }

int fs_flush(void)
{
    if (!mounted || !backing || !ata_present())
        return -1;
    u32 total = sb.block_count;
    u32 done = 0;
    while (done < total) {
        u32 chunk = total - done;
        if (chunk > 64) chunk = 64;
        if (ata_write(backing_lba + done, (u8)chunk, fs_base + (u64)done * 512) != 0)
            return -2;
        done += chunk;
    }
    return ata_flush() == 0 ? 0 : -3;
}
