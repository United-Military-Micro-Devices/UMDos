/* kmain.c - 内核主流程：启动画面 -> 登录 -> 桌面 */
#include "bootinfo.h"
#include "gfx.h"
#include "input.h"
#include "fs.h"
#include "ui.h"
#include "io.h"

void kmain(bootinfo_t *bi)
{
    gfx_info gi;
    gi.base = bi->fb_base_lo;
    gi.width = bi->fb_width;
    gi.height = bi->fb_height;
    gi.stride = bi->fb_stride;
    gi.bpp = bi->fb_bpp;
    gfx_init(&gi);
    input_init();

    outb(0xE9, 0x01);

    ui_splash(bi);                  /* 蓝色启动画面 + 加载 + 约 60 秒 */
    ui_login(bi);                   /* 校验用户名/密码 */

    outb(0xE9, 0x40);
    ui_desktop(bi);                 /* 桌面：我的电脑 -> 文件管理器 */

    for (;;)
        ;
}
